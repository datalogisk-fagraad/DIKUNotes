module ParserImpl where

-- put your parser in this file. Do not change the types of the following
-- exported functions

import Defs
import Utils

parseVersion :: String -> Either ErrMsg Version
parseVersion = undefined

parseDatabase :: String -> Either ErrMsg Database
parseDatabase = undefined
